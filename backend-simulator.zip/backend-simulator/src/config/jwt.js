const JWT_SECRET = '12345HM@'
const JWT_EXPIRES_IN = '1h'

module.exports = {
  JWT_SECRET,
  JWT_EXPIRES_IN,
}
